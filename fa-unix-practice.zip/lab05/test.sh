#!/usr/bin/bash

DATE=$(date +%T)
echo $DATE > /tmp/$DATE.txt
